// app.js - Núcleo Global da SPA, Autenticação, Menu, Roteador e Responsividade
const EMAIL_SUPERUSUARIO = "leoignacio@gmail.com"; 

window.usuarioAtual = { email: null, cargo: null, nome: null, sobrenome: null, perfis: [], areas: [] };
window.emProcessoDePreCadastro = false;

// Estado responsivo da Sidebar e controle de transição de Breakpoint (768px)
let lastIsMobile = window.innerWidth < 768;
let isSidebarCollapsed = lastIsMobile; 

const UI = {
    load: document.getElementById('loading-screen'),
    login: document.getElementById('login-screen'),
    root: document.getElementById('app-root')
};

// ==========================================
// 1. AUTENTICAÇÃO E VERIFICAÇÃO DE CREDENCIAMENTO
// ==========================================
window.auth.onAuthStateChanged(async (user) => {
    if (window.emProcessoDePreCadastro) return;

    if (user) {
        UI.login.classList.add('hidden');
        UI.load.classList.remove('hidden');
        document.getElementById('loading-text').innerText = "Verificando credenciamento...";
        
        const emailAuth = typeof user.email === 'string' ? user.email : '';
        const isSuperUser = (emailAuth.toLowerCase() === EMAIL_SUPERUSUARIO.toLowerCase());
        let cargo;
        try {
            cargo = await window.Controller.obterPerfil(user, isSuperUser);
        } catch (err) {
            // Ex.: sem internet, regras do Firestore ou limite diário do plano gratuito atingido.
            console.error('[Auth] Falha ao verificar credenciamento:', err);
            UI.load.classList.add('hidden');
            UI.login.classList.remove('hidden');
            await window.auth.signOut();
            await window.Dialog.erro(err, 'Não foi possível verificar seu credenciamento');
            return;
        }

        if (cargo === 'nao_cadastrado') {
            UI.load.classList.add('hidden');
            UI.login.classList.remove('hidden');
            if (window.AppUsuarios) {
                window.AppUsuarios.abrirModalPreCadastro(user);
            }
            return;
        }

        if (cargo === 'sem_acesso') {
            await window.auth.signOut();
            await window.Dialog.aviso("Seu perfil encontra-se bloqueado ou sem permissão de acesso.", "Acesso negado");
            return;
        }

        let dadosUsuario = null;
        try {
            dadosUsuario = window.ControllerUsuarios ? window.ControllerUsuarios.obterMeuUsuario() : null;
        } catch (err) {
            console.warn('[Auth] Não foi possível carregar os dados do usuário:', err);
        }
        window.usuarioAtual = {
            id: dadosUsuario?.id || null,
            uid: user.uid || null,
            email: user.email.toLowerCase(),
            cargo: cargo,
            nome: dadosUsuario?.nome || "",
            sobrenome: dadosUsuario?.sobrenome || "",
            nome_completo: dadosUsuario?.nome_completo || user.displayName || user.email,
            cargo_solicitado: dadosUsuario?.cargo_solicitado || "docente",
            solicitacao_credenciamento: dadosUsuario?.solicitacao_credenciamento || "",
            perfis: dadosUsuario?.perfis || (cargo === 'pendente' ? [] : [cargo]),
            areas: dadosUsuario?.areas || []
        };

        // Cada usuário ativo publica somente seu próprio registro mínimo de destinatário.
        if (window.ControllerAdminCredenciamento?.publicarMeuDestinatario) {
            window.ControllerAdminCredenciamento.publicarMeuDestinatario()
                .catch(err => console.warn('[Diretório] Registro mínimo do usuário não publicado:', err));
        }
        // Root/Admin também mantêm sincronizada a lista completa sem expor a coleção usuarios aos demais perfis.
        if (['root', 'admin'].includes(cargo) && window.ControllerAdminCredenciamento?.sincronizarDiretorio) {
            setTimeout(() => window.ControllerAdminCredenciamento.sincronizarDiretorio()
                .catch(err => console.warn('[Diretório] Sincronização não concluída:', err)), 1500);
        }

        UI.load.classList.add('hidden');
        UI.root.classList.remove('hidden');
        // Cada autenticação começa no Dashboard; a view seleciona a guia inicial adequada ao perfil.
        if (window.location.hash && window.location.hash !== '#/dashboard') window.location.hash = '#/dashboard';
        else roteador();
    } else {
        if (window.Store) window.Store.limpar();
        window.usuarioAtual = { email: null, cargo: null, nome: null, sobrenome: null, perfis: [], areas: [] };
        UI.root.innerHTML = '';
        UI.root.classList.add('hidden');
        UI.load.classList.add('hidden');
        UI.login.classList.remove('hidden');
    }
});

document.getElementById('btn-google-login').onclick = () => {
    window.auth.signInWithPopup(window.googleProvider).catch(err => {
        if (['auth/popup-closed-by-user', 'auth/cancelled-popup-request'].includes(err.code)) return; // fechou a janela: não é erro
        window.Dialog.erro(err, 'Erro ao autenticar');
    });
};

document.getElementById('login-form').onsubmit = (e) => {
    e.preventDefault();
    window.auth.signInWithEmailAndPassword(document.getElementById('email-input').value, document.getElementById('password-input').value)
        .catch(err => window.Dialog.erro(err, 'Erro ao autenticar'));
};

// ==========================================
// 2. CONTROLE VISUAL (SIDEBAR RESPONSIVA)
// ==========================================
function applySidebarState() {
    const sidebar = document.getElementById('main-sidebar');
    if(!sidebar) return;
    
    const backdrop = document.getElementById('sidebar-backdrop');
    const texts = sidebar.querySelectorAll('.sidebar-text');
    const btnToggleClose = document.getElementById('btn-toggle-sidebar');
    const btnToggleOpen = document.getElementById('btn-toggle-sidebar-open');
    const btnLogoutIcon = document.getElementById('btn-logout-icon');
    const btnLogoutText = document.getElementById('btn-logout');
    const links = sidebar.querySelectorAll('nav a');
    const footerDiv = sidebar.querySelector('.bg-slate-50');

    const isMobile = window.innerWidth < 768;

    if (isMobile) {
        // No mobile, a sidebar é SEMPRE fixed (fora do fluxo flex-col para nunca empurrar a view para baixo)
        if (isSidebarCollapsed) {
            sidebar.className = "fixed inset-y-0 left-0 -translate-x-full w-64 bg-white border-r border-slate-200 flex flex-col justify-between z-50 transition-transform duration-300 shadow-2xl";
            if (backdrop) backdrop.classList.add('hidden');
        } else {
            sidebar.className = "fixed inset-y-0 left-0 translate-x-0 w-64 bg-white border-r border-slate-200 flex flex-col justify-between z-50 transition-transform duration-300 shadow-2xl";
            if (backdrop) backdrop.classList.remove('hidden');
        }
        texts.forEach(t => t.classList.remove('hidden'));
        if(btnToggleClose) btnToggleClose.classList.remove('hidden');
        if(btnToggleOpen) btnToggleOpen.classList.add('hidden');
        if(btnLogoutIcon) btnLogoutIcon.classList.add('hidden');
        if(btnLogoutText) btnLogoutText.classList.remove('hidden');
        if(footerDiv) footerDiv.classList.remove('items-center', 'px-0');
        links.forEach(l => { l.classList.add('px-4'); l.classList.remove('px-0', 'justify-center'); });
    } else {
        // No desktop, oculta o backdrop mobile e posiciona na lateral (relative)
        if (backdrop) backdrop.classList.add('hidden');

        if (isSidebarCollapsed) {
            sidebar.className = "relative w-20 bg-white border-r border-slate-200 flex flex-col justify-between z-30 transition-all duration-300 flex-shrink-0 shadow-sm translate-x-0";
            texts.forEach(t => t.classList.add('hidden'));
            if(btnToggleClose) btnToggleClose.classList.add('hidden');
            if(btnToggleOpen) btnToggleOpen.classList.remove('hidden');
            if(btnLogoutIcon) btnLogoutIcon.classList.remove('hidden');
            if(btnLogoutText) btnLogoutText.classList.add('hidden');
            if(footerDiv) footerDiv.classList.add('items-center', 'px-0');
            links.forEach(l => { l.classList.remove('px-4'); l.classList.add('px-0', 'justify-center'); });
        } else {
            sidebar.className = "relative w-64 bg-white border-r border-slate-200 flex flex-col justify-between z-30 transition-all duration-300 flex-shrink-0 shadow-sm translate-x-0";
            texts.forEach(t => t.classList.remove('hidden'));
            if(btnToggleClose) btnToggleClose.classList.remove('hidden');
            if(btnToggleOpen) btnToggleOpen.classList.add('hidden');
            if(btnLogoutIcon) btnLogoutIcon.classList.add('hidden');
            if(btnLogoutText) btnLogoutText.classList.remove('hidden');
            if(footerDiv) footerDiv.classList.remove('items-center', 'px-0');
            links.forEach(l => { l.classList.add('px-4'); l.classList.remove('px-0', 'justify-center'); });
        }
    }
}

// Monitora redimensionamento garantindo a atualização imediata mesmo se a sidebar já estava recolhida no desktop
window.addEventListener('resize', () => {
    const isMobile = window.innerWidth < 768;
    if (isMobile !== lastIsMobile) {
        lastIsMobile = isMobile;
        // Ao entrar no modo mobile, garante que o menu inicie recolhido fora da tela
        if (isMobile) {
            isSidebarCollapsed = true;
        }
    }
    applySidebarState();
});

// ==========================================
// 3. ROTEAMENTO COM PROTEÇÃO POR PERFIL
// ==========================================
async function roteador() {
    let hash = window.location.hash || '#/dashboard';
    const cargoAtual = window.usuarioAtual?.cargo;

    // Compatibilidade com links antigos para o menu renomeado.
    if (hash === '#/docentes') {
        window.location.hash = '#/area-docentes';
        return;
    }

    if (cargoAtual === 'pendente' && hash !== '#/dashboard') {
        window.location.hash = '#/dashboard';
        return;
    }

    if (hash === '#/excecoes' && !['root', 'admin'].includes(cargoAtual)) {
        window.location.hash = '#/dashboard';
        return;
    }

    if (hash === '#/admin' && !['root', 'admin'].includes(cargoAtual)) { 
        window.location.hash = '#/dashboard'; 
        return; 
    }

    // Garante que no mobile toda troca de rota inicie com o menu lateral recolhido
    if (window.innerWidth < 768) {
        isSidebarCollapsed = true;
    }

    UI.root.innerHTML = `
        <div class="md:hidden w-full h-14 bg-blue-600 flex items-center justify-between px-4 shadow-md z-40 fixed top-0 left-0 right-0">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 bg-white rounded flex items-center justify-center text-blue-600 font-bold">IT</div>
                <span class="text-white font-bold text-lg">InovaTech</span>
            </div>
            <button id="btn-mobile-menu" class="text-white hover:text-blue-200 focus:outline-none">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </div>
        ${window.Views.sidebar(window.usuarioAtual)}
        <div id="view-content" class="flex-1 bg-slate-50 flex overflow-hidden pt-14 md:pt-0 relative w-full min-h-0"></div>
    `;
    
    applySidebarState(); 
    const viewContainer = document.getElementById('view-content');
    const podeEditarOperacional = ['root', 'admin', 'tecnico', 'docente'].includes(cargoAtual);

    switch(hash) {
        case '#/dashboard':
            viewContainer.innerHTML = window.ViewsDashboard ? window.ViewsDashboard.renderizar() : window.Views.dashboard();
            if (window.AppDashboard) await window.AppDashboard.iniciarView();
            break;
        case '#/excecoes': {
            const podeEditarCalendario = ['root', 'admin'].includes(cargoAtual);
            viewContainer.innerHTML = window.ViewsCalendarioListar.renderizar(podeEditarCalendario); 
            if (window.AppCalendarioListar) await window.AppCalendarioListar.iniciarView();
            break;
        }
        case '#/cursos': {
            viewContainer.innerHTML = window.ViewsCursoListar.renderizar(podeEditarOperacional); 
            if (window.AppCursoListar) await window.AppCursoListar.iniciarView();
            break;
        }
        case '#/turmas': {
            viewContainer.innerHTML = window.ViewsTurmaListar.renderizar(podeEditarOperacional);
            if (window.AppTurmaListar) await window.AppTurmaListar.iniciarView();
            break;
        }
        case '#/area-docentes':
            viewContainer.innerHTML = window.ViewsDocente ? window.ViewsDocente.renderizar() : window.Views.docentes();
            if (window.AppDocente) await window.AppDocente.iniciarView();
            break;
        case '#/coordenacao': viewContainer.innerHTML = window.Views.coordenacao(); break;
        case '#/apoio-tecnico':
            viewContainer.innerHTML = window.ViewsApoio.renderizar(window.usuarioAtual);
            if (window.AppApoio) await window.AppApoio.iniciarView();
            break;
        case '#/espelho': {
            viewContainer.innerHTML = window.ViewsEspelho.renderizar(podeEditarOperacional);
            if (window.AppEspelho) await window.AppEspelho.iniciarView();
            break;
        }
        case '#/admin': 
            viewContainer.innerHTML = window.ViewsAdminCredenciamento.renderizar(); 
            if (window.AppAdminCredenciamento) await window.AppAdminCredenciamento.iniciarView();
            break;
        default: viewContainer.innerHTML = window.Views.dashboard();
    }
}
window.addEventListener('hashchange', roteador);

// O Store mantém uma assinatura por coleção; a UI revalida no máximo uma vez por rajada.
let _storeRefreshTimer = null;
window.Store.onUpdateCallback = () => {
    if (_storeRefreshTimer) clearTimeout(_storeRefreshTimer);
    _storeRefreshTimer = setTimeout(() => {
        if (!window.usuarioAtual?.email || document.hidden || UI.root.classList.contains('hidden')) return;
        if (document.querySelector('[role="dialog"]:not(.hidden)')) return;
        // Apoio Técnico: reavalia a lista sem recarregar a tela (mantém filtros e rolagem).
        if (window.location.hash === '#/apoio-tecnico' && window.AppApoio?.atualizarSuave && document.getElementById('apoio-lista')) { window.AppApoio.atualizarSuave(); return; }
        const pendentes = window.AppEspelho?.pendenciasArraste;
        if (pendentes?.size || window.AppEspelho?.alvosEdicaoLote?.size) return;
        // Espelho: atualização suave (mantém a rolagem exatamente onde está). Demais telas: re-render completo.
        if (window.location.hash === '#/dashboard' && window.AppDashboard?.atualizarSuave) { window.AppDashboard.atualizarSuave(); return; }
        if (window.location.hash === '#/area-docentes' && window.AppDocente?.atualizarSuave) { window.AppDocente.atualizarSuave(); return; }
        if (window.location.hash === '#/espelho' && window.AppEspelho?.atualizarSuave && document.getElementById('espelho-painel')) {
            window.AppEspelho.atualizarSuave().catch(() => roteador());
            return;
        }
        roteador();
    }, 220);
};

// ==========================================
// 4. DELEGAÇÃO DE EVENTOS GLOBAIS
// ==========================================
document.addEventListener('submit', async (e) => {
    // Prevent default synchronously: awaiting any async module before this can reload the page
    // before the Espelho or another view reaches its own submit handler.
    if (e.target.id !== 'login-form') e.preventDefault();
    if (window.AppUsuarios && await window.AppUsuarios.tratarSubmits(e)) return;
    if (window.AppDashboard && await window.AppDashboard.tratarSubmits(e)) return;
    if (window.AppDocente && await window.AppDocente.tratarSubmits(e)) return;
    // Informações pessoais do Apoio (inclui perfil Apoio: edita apenas o próprio cadastro).
    if (window.usuarioAtual.cargo !== 'pendente' && window.AppApoio && await window.AppApoio.tratarSubmits(e)) return;

    if (window.usuarioAtual.cargo === 'pendente') {
        e.preventDefault();
        return window.Dialog.aviso("Aguardando credenciamento. Esta operação só será liberada após a análise da sua solicitação.", "Acesso restrito");
    }

    if(window.usuarioAtual.cargo === 'apoio') {
        e.preventDefault();
        return window.Dialog.aviso("Seu perfil é somente leitura e não permite gravar alterações.", "Perfil somente leitura");
    }
    
    if (window.AppCalendarioFrms && await window.AppCalendarioFrms.tratarSubmits(e)) return;
    if (window.AppCursoFrm && await window.AppCursoFrm.tratarSubmits(e)) return;
    if (window.AppTurmaFrm && await window.AppTurmaFrm.tratarSubmits(e)) return;
    if (window.AppEspelho && await window.AppEspelho.tratarSubmits(e)) return;
    if (window.AppAdminCredenciamento && await window.AppAdminCredenciamento.tratarSubmits(e)) return;
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.id === 'popover-input-cal-desc') {
        e.preventDefault();
        document.getElementById('apply-filter-cal-desc')?.click();
    }
    if (e.key === 'Enter' && e.target.id === 'popover-input-curso-titulo') {
        e.preventDefault();
        document.getElementById('apply-filter-curso-titulo')?.click();
    }
    if (e.key === 'Enter' && e.target.id === 'popover-input-turma-ref') {
        e.preventDefault();
        document.getElementById('apply-filter-turma-ref')?.click();
    }
});

document.addEventListener('change', async (e) => {
    if (window.AppDocente && await window.AppDocente.tratarMudancas(e)) return;
    if (window.AppDashboard && await window.AppDashboard.tratarMudancas(e)) return;
    if (window.AppApoio && await window.AppApoio.tratarMudancas(e)) return;
    if (window.AppEspelho && await window.AppEspelho.tratarMudancas(e)) return;
});

document.addEventListener('click', async (e) => {
    
    if (window.AppUsuarios && await window.AppUsuarios.tratarCliques(e)) return;
    if (window.AppDocente && await window.AppDocente.tratarCliques(e)) return;
    if (window.AppDashboard && await window.AppDashboard.tratarCliques(e)) return;

    if (e.target.closest('#btn-mobile-menu') || e.target.closest('#sidebar-backdrop')) {
        isSidebarCollapsed = !isSidebarCollapsed;
        applySidebarState();
        return;
    }

    if(e.target.closest('#btn-toggle-sidebar') || e.target.closest('#btn-toggle-sidebar-open')) {
        isSidebarCollapsed = !isSidebarCollapsed;
        applySidebarState();
        return;
    }

    if (window.innerWidth < 768 && e.target.closest('nav a') && !isSidebarCollapsed) {
        isSidebarCollapsed = true;
        applySidebarState();
    }

    if(e.target.closest('#btn-logout') || e.target.closest('#btn-logout-icon')) { window.auth.signOut(); return; }

    if (window.usuarioAtual.cargo !== 'pendente') {
        if (window.AppCalendarioListar && await window.AppCalendarioListar.tratarCliques(e)) return;
        if (window.AppCalendarioFrms && await window.AppCalendarioFrms.tratarCliques(e)) return;
        if (window.AppCursoListar && await window.AppCursoListar.tratarCliques(e)) return;
        if (window.AppCursoFrm && await window.AppCursoFrm.tratarCliques(e)) return;
        if (window.AppTurmaListar && await window.AppTurmaListar.tratarCliques(e)) return;
        if (window.AppTurmaFrm && await window.AppTurmaFrm.tratarCliques(e)) return;
        if (window.AppApoio && await window.AppApoio.tratarCliques(e)) return;
        if (window.AppEspelho && await window.AppEspelho.tratarCliques(e)) return;
        if (window.AppAdminCredenciamento && await window.AppAdminCredenciamento.tratarCliques(e)) return;
    }

    const tabBtn = e.target.closest('.tab-btn');
    if (tabBtn) {
        const target = tabBtn.getAttribute('data-target') || '';
        const dashboardTab = target.startsWith('tab-dashboard-');
        const botoes = dashboardTab ? document.querySelectorAll('#dashboard-root > nav .tab-btn') : document.querySelectorAll('.tab-btn');
        botoes.forEach(btn => {
            btn.classList.remove('font-bold', 'text-blue-600', 'border-blue-600');
            btn.classList.add('font-medium', 'text-slate-500', 'border-transparent');
        });
        tabBtn.classList.remove('font-medium', 'text-slate-500', 'border-transparent');
        tabBtn.classList.add('font-bold', 'text-blue-600', 'border-blue-600');
        const tabContainer = dashboardTab
            ? document.querySelectorAll('#dashboard-root > main > .tab-content[id^="tab-dashboard-"]')
            : tabBtn.closest('.flex-col').querySelectorAll('.tab-content');
        tabContainer.forEach(content => content.classList.add('hidden'));
        document.getElementById(target)?.classList.remove('hidden');
    }
});
